/**
 * Created by JANVI on 13/10/2019.
 */
public class testReturnString {
    public static void main(String[] args) {
        randomEmailGenerator objr = new randomEmailGenerator();
      //  objr.getSaltString();
       // getSaltString()+"@gmail.com"





    }



}
