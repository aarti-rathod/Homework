import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.util.concurrent.TimeUnit;

/**
 * Created by JANVI on 06/10/2019.
 */
public class explorerTest {

    public void runExp(){



        String baseUrl="https://learn.letskodeit.com/p/practice";
        WebDriver driver;

        System.setProperty("webdriver.ie.driver","drivers/IEDriverServer.exe");
        driver= new InternetExplorerDriver();        //U need to rememeber by heart

        driver.get(baseUrl);

        WebElement loginlF=driver.findElement(By.linkText("Login"));
        loginlF.click();

        //driver.findElement(By.xpath("//a[@href='/sign_in']")).click();;

        WebElement emailF=driver.findElement(By.id("user_email"));
        emailF.sendKeys("abchdj@gmail.com");

        WebElement passworfi=driver.findElement(By.id("user_password"));
        passworfi.sendKeys("abs12334");

        WebElement loginbtn=driver.findElement(By.name("commit"));
        loginbtn.click();


    }
}



