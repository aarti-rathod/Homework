import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;

import java.util.concurrent.TimeUnit;



    public class chromeTest {

        public void run() {


            String baseUrl="https://demo.nopcommerce.com/";
            WebDriver driver;


            System.setProperty("webdriver.chrome.driver","C:\\Users\\JANVI\\IdeaProjects\\selenium-webdriver-practice\\drivers\\chromedriver.exe");


            driver=new ChromeDriver();

//            InternetExplorerOptions capabilities = new InternetExplorerOptions();
//            capabilities.ignoreZoomSettings();
//            driver = new InternetExplorerDriver(capabilities);

            driver.get(baseUrl);            // Need to Rememeber by heart
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            //  path "drivers/chromedriver.exe" need to use when submit the homework

            //Find Elements for Login

            WebElement loginLi=driver.findElement(By.xpath(".//a[@class='ico-login']"));      //Taken xpath
            loginLi.click();

            WebElement emailF=driver.findElement(By.id("Email"));
            emailF.sendKeys("anjali004@gmail.com");

            WebElement passworfi=driver.findElement(By.id("Password"));
            passworfi.sendKeys("888812334");

            WebElement loginbtn=driver.findElement(By.xpath(".//input[@value='Log in']"));
            loginbtn.click();
        }
    }



