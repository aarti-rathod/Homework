import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

/**
 * Created by JANVI on 06/10/2019.
 */
public class mozilaTest {
    public void runMozila(){


        String baseUrl="https://demo.nopcommerce.com/";
        WebDriver driver;


        //System.setProperty("webdriver.chrome.driver","C:\\Users\\JANVI\\IdeaProjects\\selenium-webdriver-practice\\drivers\\chromedriver.exe");

        /*
         System.setProperty(“webdriver.gecko.driver”, “<Path to your WebDriver>”), what is meant by “Path to your WebDriver”?
         */

        System.setProperty("webdriver.gecko.driver","C:\\Users\\JANVI\\IdeaProjects\\WeekTenHomeWork\\drivers\\geckodriver.exe");


        //C:\Users\JANVI\IdeaProjects\WeekTenHomeWork\drivers\geckodriver.exe


        driver=new FirefoxDriver();                                        //Need to Rememeber by heart

        driver.get(baseUrl);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //  path "drivers/chromedriver.exe" need to use when submit the homework

        //Find Elements for login

        WebElement loginLi=driver.findElement(By.xpath(".//a[@class='ico-login']"));
        loginLi.click();

        WebElement emailF=driver.findElement(By.id("Email"));
        emailF.sendKeys("anjali004@gmail.com");

        WebElement passworfi=driver.findElement(By.id("Password"));
        passworfi.sendKeys("88812334");

        WebElement loginbtn=driver.findElement(By.xpath(".//input[@value='Log in']"));
        loginbtn.click();





    }
}
